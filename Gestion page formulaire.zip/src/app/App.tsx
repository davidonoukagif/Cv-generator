import { useState, useEffect } from "react";
import { CVForm } from "./components/cv-form";
import { ModernTemplate } from "./components/cv-templates/modern-template";
import { ClassicTemplate } from "./components/cv-templates/classic-template";
import type { CVData, TemplateType } from "./types/cv.types";
import { saveCVData, loadCVData, clearCVData } from "./utils/storage";
import html2pdf from "html2pdf.js";
import { toast } from "sonner";
import { Toaster } from "./components/ui/sonner";
import { LandingPage } from "./components/landing-page";
import { CVBuilder } from "./components/cv-builder";

const initialCVData: CVData = {
  personalInfo: { fullName: "", email: "", phone: "", address: "", linkedin: "", website: "", password: "" },
  education: [],
  experience: [],
  skills: [],
  interests: []
};

export default function App() {
  const [page, setPage] = useState<"landing" | "builder">("landing");
  const [cvData, setCvData] = useState<CVData>(initialCVData);
  const [selectedTemplate, setSelectedTemplate] = useState<TemplateType>("modern");
  const [isSaving, setIsSaving] = useState(false);
  const [lastSaved, setLastSaved] = useState<Date | null>(null);

  useEffect(() => {
    const savedData = loadCVData();
    if (savedData) {
      setCvData(savedData);
    }
  }, []);

  useEffect(() => {
    if (cvData.personalInfo.fullName || cvData.personalInfo.email) {
      setIsSaving(true);
      const timer = setTimeout(() => {
        saveCVData(cvData);
        setIsSaving(false);
        setLastSaved(new Date());
      }, 800);
      return () => clearTimeout(timer);
    }
  }, [cvData]);

  const handleExportPDF = () => {
    const element = document.getElementById("cv-content");
    if (!element) { toast.error("Erreur lors de la génération du PDF"); return; }
    const opt = {
      margin: 10,
      filename: `CV_${cvData.personalInfo.fullName || "MonCV"}.pdf`,
      image: { type: "jpeg", quality: 0.98 },
      html2canvas: { scale: 2 },
      jsPDF: { unit: "mm", format: "a4", orientation: "portrait" }
    };
    toast.promise(html2pdf().set(opt).from(element).save(), {
      loading: "Génération du PDF…",
      success: "🎉 CV exporté avec succès !",
      error: "Erreur lors de l'export"
    });
  };

  const handleClearData = () => {
    if (confirm("Effacer toutes les données ?")) {
      clearCVData(); setCvData(initialCVData); toast.success("Données effacées");
    }
  };

  const completionScore = () => {
    let s = 0;
    const p = cvData.personalInfo;
    if (p.fullName) s += 20; if (p.email) s += 10; if (p.phone) s += 10;
    if (p.address) s += 5; if (cvData.education.length) s += 15;
    if (cvData.experience.length) s += 20; if (cvData.skills.length) s += 15;
    if (cvData.interests.length) s += 5;
    return Math.min(s, 100);
  };

  if (page === "landing") {
    return (
      <>
        <Toaster position="top-right" richColors />
        <LandingPage onStart={() => setPage("builder")} cvData={cvData} selectedTemplate={selectedTemplate} />
      </>
    );
  }

  return (
    <>
      <Toaster position="top-right" richColors />
      <CVBuilder
        cvData={cvData}
        selectedTemplate={selectedTemplate}
        isSaving={isSaving}
        lastSaved={lastSaved}
        score={completionScore()}
        onDataChange={setCvData}
        onTemplateChange={setSelectedTemplate}
        onExportPDF={handleExportPDF}
        onClear={handleClearData}
        onBack={() => setPage("landing")}
      />
    </>
  );
}
