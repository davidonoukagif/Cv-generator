import { useState } from "react";
import { CVForm } from "./cv-form";
import { ModernTemplate } from "./cv-templates/modern-template";
import { ClassicTemplate } from "./cv-templates/classic-template";
import type { CVData, TemplateType } from "../types/cv.types";
import {
  FileText, Download, Trash2, Save, Eye, ChevronLeft,
  LayoutTemplate, Sparkles, CheckCircle2, Clock
} from "lucide-react";

interface CVBuilderProps {
  cvData: CVData;
  selectedTemplate: TemplateType;
  isSaving: boolean;
  lastSaved: Date | null;
  score: number;
  onDataChange: (data: CVData) => void;
  onTemplateChange: (t: TemplateType) => void;
  onExportPDF: () => void;
  onClear: () => void;
  onBack: () => void;
}

const scoreColor = (s: number) => s >= 80 ? "linear-gradient(135deg, #10b981, #059669)" : s >= 50 ? "linear-gradient(135deg, #f59e0b, #f97316)" : "linear-gradient(135deg, #ef4444, #dc2626)";
const scoreLabel = (s: number) => s >= 80 ? "Excellent !" : s >= 50 ? "En bonne voie" : "À compléter";
const scoreTextColor = (s: number) => s >= 80 ? "#10b981" : s >= 50 ? "#f59e0b" : "#ef4444";

export function CVBuilder({
  cvData, selectedTemplate, isSaving, lastSaved, score,
  onDataChange, onTemplateChange, onExportPDF, onClear, onBack
}: CVBuilderProps) {
  const [mobileView, setMobileView] = useState<"form" | "preview">("form");

  return (
    <div style={{ minHeight: "100vh", background: "linear-gradient(135deg, #fdf4ff 0%, #dbeafe 50%, #f0fdf4 100%)", fontFamily: "'Inter', system-ui, sans-serif" }}>
      {/* Top Bar */}
      <header style={{
        background: "rgba(255,255,255,0.9)",
        backdropFilter: "blur(12px)",
        borderBottom: "2px solid rgba(139,92,246,0.15)",
        padding: "0 24px",
        height: 60,
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        position: "sticky",
        top: 0,
        zIndex: 100,
        boxShadow: "0 4px 20px rgba(139,92,246,0.2)"
      }}>
        {/* Left: Back + Logo */}
        <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
          <button
            onClick={onBack}
            style={{
              display: "flex", alignItems: "center", gap: 6,
              background: "linear-gradient(135deg, rgba(236,72,153,0.1), rgba(139,92,246,0.1))", 
              border: "2px solid rgba(139,92,246,0.2)",
              borderRadius: 10, padding: "7px 14px",
              fontSize: "0.8rem", 
              fontWeight: 700,
              cursor: "pointer",
              transition: "all 0.2s",
              color: "#8b5cf6"
            }}
            onMouseEnter={e => { 
              e.currentTarget.style.borderColor = "#8b5cf6"; 
              e.currentTarget.style.background = "linear-gradient(135deg, #ec4899, #8b5cf6)";
              e.currentTarget.style.color = "#fff";
              e.currentTarget.style.transform = "translateX(-3px)";
            }}
            onMouseLeave={e => { 
              e.currentTarget.style.borderColor = "rgba(139,92,246,0.2)"; 
              e.currentTarget.style.background = "linear-gradient(135deg, rgba(236,72,153,0.1), rgba(139,92,246,0.1))";
              e.currentTarget.style.color = "#8b5cf6";
              e.currentTarget.style.transform = "translateX(0)";
            }}
          >
            <ChevronLeft size={15} />
            Accueil
          </button>

          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <div style={{
              width: 34, height: 34, borderRadius: 10,
              background: "linear-gradient(135deg, #ec4899, #8b5cf6, #06b6d4)",
              backgroundSize: "200% 200%",
              animation: "gradientShift 3s ease infinite",
              display: "flex", alignItems: "center", justifyContent: "center",
              boxShadow: "0 4px 16px rgba(139,92,246,0.5)"
            }}>
              <FileText size={16} color="#fff" />
            </div>
            <span style={{ 
              fontWeight: 900, fontSize: "0.95rem", 
              background: "linear-gradient(135deg, #ec4899, #8b5cf6)", 
              WebkitBackgroundClip: "text", 
              WebkitTextFillColor: "transparent" 
            }}>CV Pro </span>
          </div>
        </div>

        {/* Center: Score */}
        <div style={{
          display: "flex", alignItems: "center", gap: 10,
          background: "rgba(255,255,255,0.8)", 
          backdropFilter: "blur(8px)",
          borderRadius: 12, padding: "8px 16px",
          border: "2px solid rgba(139,92,246,0.2)",
          boxShadow: "0 4px 16px rgba(139,92,246,0.15)"
        }}>
          <div style={{ width: 90, height: 8, background: "rgba(0,0,0,0.05)", borderRadius: 8, overflow: "hidden" }}>
            <div style={{
              height: "100%",
              width: `${score}%`,
              borderRadius: 8,
              background: scoreColor(score),
              transition: "width 0.6s cubic-bezier(0.4, 0, 0.2, 1)",
              boxShadow: `0 0 12px ${scoreTextColor(score)}60`
            }} />
          </div>
          <span style={{ fontSize: "0.78rem", fontWeight: 800, color: scoreTextColor(score) }}>
            {score}% — {scoreLabel(score)}
          </span>
          <Sparkles size={14} style={{ color: "#f59e0b", animation: "pulse 2s ease-in-out infinite" }} />
        </div>

        {/* Right: Save indicator + Actions */}
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          {/* Save status */}
          <div style={{ display: "flex", alignItems: "center", gap: 5, fontSize: "0.75rem" }}>
            {isSaving ? (
              <span style={{ 
                color: "#f59e0b", 
                display: "flex", 
                alignItems: "center", 
                gap: 4,
                fontWeight: 700
              }}>
                <Clock size={13} style={{ animation: "spin 2s linear infinite" }} />
                Sauvegarde…
              </span>
            ) : lastSaved ? (
              <span style={{ 
                color: "#10b981", 
                display: "flex", 
                alignItems: "center", 
                gap: 4,
                fontWeight: 700
              }}>
                <CheckCircle2 size={13} />
                Sauvegardé
              </span>
            ) : null}
          </div>

          <button
            onClick={onClear}
            style={{
              display: "flex", alignItems: "center", gap: 6,
              background: "linear-gradient(135deg, rgba(239,68,68,0.1), rgba(220,38,38,0.1))", 
              border: "2px solid rgba(239,68,68,0.3)",
              color: "#ef4444", borderRadius: 10, padding: "8px 16px",
              fontSize: "0.8rem", fontWeight: 700, cursor: "pointer",
              transition: "all 0.2s"
            }}
            onMouseEnter={e => { 
              e.currentTarget.style.background = "linear-gradient(135deg, #ef4444, #dc2626)"; 
              e.currentTarget.style.color = "#fff";
              e.currentTarget.style.transform = "translateY(-2px)";
            }}
            onMouseLeave={e => { 
              e.currentTarget.style.background = "linear-gradient(135deg, rgba(239,68,68,0.1), rgba(220,38,38,0.1))"; 
              e.currentTarget.style.color = "#ef4444";
              e.currentTarget.style.transform = "translateY(0)";
            }}
          >
            <Trash2 size={14} />
            Effacer
          </button>

          <button
            onClick={onExportPDF}
            style={{
              display: "flex", alignItems: "center", gap: 7,
              background: "linear-gradient(135deg, #ec4899, #8b5cf6, #06b6d4)",
              backgroundSize: "200% 200%",
              animation: "gradientShift 3s ease infinite",
              color: "#fff", border: "none", borderRadius: 10,
              padding: "9px 20px", fontSize: "0.85rem", fontWeight: 800,
              cursor: "pointer",
              boxShadow: "0 4px 20px rgba(139,92,246,0.5)",
              transition: "all 0.3s"
            }}
            onMouseEnter={e => { 
              e.currentTarget.style.transform = "translateY(-2px)"; 
              e.currentTarget.style.boxShadow = "0 8px 30px rgba(139,92,246,0.6)";
            }}
            onMouseLeave={e => { 
              e.currentTarget.style.transform = "translateY(0)"; 
              e.currentTarget.style.boxShadow = "0 4px 20px rgba(139,92,246,0.5)";
            }}
          >
            <Download size={15} />
            Exporter PDF
          </button>
        </div>
      </header>

      {/* Mobile Toggle */}
      <div style={{
        display: "flex", margin: "12px 16px",
        background: "rgba(255,255,255,0.9)", borderRadius: 14,
        border: "2px solid rgba(139,92,246,0.2)", padding: 4,
        gap: 4,
        boxShadow: "0 4px 16px rgba(139,92,246,0.15)"
      }} className="lg-hidden">
        {([["form", "#ec4899"], ["preview", "#06b6d4"]] as const).map(([v, color]) => (
          <button
            key={v}
            onClick={() => setMobileView(v)}
            style={{
              flex: 1, padding: "10px 0", borderRadius: 10, border: "none",
              background: mobileView === v ? `linear-gradient(135deg, ${color}, #8b5cf6)` : "transparent",
              color: mobileView === v ? "#fff" : "#64748b",
              fontSize: "0.85rem", fontWeight: 700, cursor: "pointer",
              display: "flex", alignItems: "center", justifyContent: "center", gap: 6,
              transition: "all 0.3s"
            }}
          >
            {v === "form" ? <><Save size={14} />Formulaire</> : <><Eye size={14} />Aperçu</>}
          </button>
        ))}
      </div>

      {/* Main */}
      <main style={{ maxWidth: 1280, margin: "0 auto", padding: "16px 20px 40px", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
        {/* Left Form Panel */}
        <div style={{ display: mobileView === "preview" ? "none" : "block" }} className="form-panel">
          {/* Section label */}
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 16 }}>
            <div style={{ 
              width: 4, height: 22, 
              background: "linear-gradient(180deg, #ec4899, #8b5cf6)", 
              borderRadius: 3,
              boxShadow: "0 2px 8px rgba(236,72,153,0.4)"
            }} />
            <span style={{ 
              fontSize: "0.8rem", fontWeight: 800, 
              background: "linear-gradient(135deg, #ec4899, #8b5cf6)", 
              WebkitBackgroundClip: "text", 
              WebkitTextFillColor: "transparent", 
              textTransform: "uppercase", 
              letterSpacing: "0.08em" 
            }}>Vos informations</span>
          </div>
          <CVForm initialData={cvData} onChange={onDataChange} />
        </div>

        {/* Right Preview Panel */}
        <div style={{ display: mobileView === "form" ? "none" : "block" }} className="preview-panel">
          <div style={{ position: "sticky", top: 76 }}>
            {/* Template switcher */}
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <div style={{ 
                  width: 4, height: 22, 
                  background: "linear-gradient(180deg, #06b6d4, #8b5cf6)", 
                  borderRadius: 3,
                  boxShadow: "0 2px 8px rgba(6,182,212,0.4)"
                }} />
                <span style={{ 
                  fontSize: "0.8rem", fontWeight: 800, 
                  background: "linear-gradient(135deg, #06b6d4, #8b5cf6)", 
                  WebkitBackgroundClip: "text", 
                  WebkitTextFillColor: "transparent", 
                  textTransform: "uppercase", 
                  letterSpacing: "0.08em" 
                }}>Aperçu en direct</span>
              </div>
              <div style={{
                display: "flex", gap: 4,
                background: "rgba(255,255,255,0.9)", borderRadius: 12, padding: 4,
                border: "2px solid rgba(139,92,246,0.2)",
                boxShadow: "0 4px 16px rgba(139,92,246,0.15)"
              }}>
                {([
                  { value: "modern", label: "Moderne", gradient: "linear-gradient(135deg, #ec4899, #8b5cf6)" },
                  { value: "classic", label: "Classique", gradient: "linear-gradient(135deg, #06b6d4, #8b5cf6)" }
                ] as const).map(t => (
                  <button
                    key={t.value}
                    onClick={() => onTemplateChange(t.value)}
                    style={{
                      display: "flex", alignItems: "center", gap: 6,
                      padding: "8px 16px", borderRadius: 9, border: "none",
                      background: selectedTemplate === t.value ? t.gradient : "transparent",
                      color: selectedTemplate === t.value ? "#fff" : "#64748b",
                      fontSize: "0.8rem", fontWeight: 700, cursor: "pointer",
                      transition: "all 0.3s",
                      boxShadow: selectedTemplate === t.value ? "0 4px 16px rgba(139,92,246,0.3)" : "none"
                    }}
                  >
                    <LayoutTemplate size={13} />
                    {t.label}
                  </button>
                ))}
              </div>
            </div>

            {/* CV Preview */}
            <div style={{
              background: "#fff",
              borderRadius: 20,
              boxShadow: "0 12px 40px rgba(139,92,246,0.2), 0 0 0 2px rgba(139,92,246,0.1)",
              overflow: "hidden",
              maxHeight: "calc(100vh - 140px)",
              overflowY: "auto",
              border: "2px solid rgba(236,72,153,0.15)"
            }}>
              {selectedTemplate === "modern"
                ? <ModernTemplate data={cvData} />
                : <ClassicTemplate data={cvData} />
              }
            </div>
          </div>
        </div>
      </main>

      <style>{`
        @media (max-width: 900px) {
          main { grid-template-columns: 1fr !important; }
          .form-panel, .preview-panel { display: block !important; }
        }
        @media (min-width: 901px) {
          .lg-hidden { display: none !important; }
          .form-panel, .preview-panel { display: block !important; }
        }
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: rgba(139,92,246,0.05); }
        ::-webkit-scrollbar-thumb { background: linear-gradient(135deg, #ec4899, #8b5cf6); border-radius: 10px; }
        
        @keyframes gradientShift {
          0%, 100% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
        }
        @keyframes pulse {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.7; transform: scale(1.1); }
        }
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
}