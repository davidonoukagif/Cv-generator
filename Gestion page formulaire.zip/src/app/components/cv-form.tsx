import { useState } from "react";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Checkbox } from "./ui/checkbox";
import {
  Plus, Trash2, User, GraduationCap, Briefcase, Award, Heart,
  ChevronDown, ChevronUp, Mail, Phone, MapPin, Linkedin, Globe, Lock
} from "lucide-react";
import type { CVData, Education, Experience, Skill, Interest } from "../types/cv.types";
import { getEmailError, getPhoneError, getPasswordError, getRequiredError } from "../utils/validation";

interface CVFormProps {
  initialData: CVData;
  onChange: (data: CVData) => void;
}

const sectionStyles = {
  personal: { bg: "from-teal-600 to-teal-700", light: "bg-teal-50", border: "border-teal-200", text: "text-teal-700", badge: "bg-teal-100 text-teal-700" },
  education: { bg: "from-indigo-500 to-violet-600", light: "bg-indigo-50", border: "border-indigo-200", text: "text-indigo-700", badge: "bg-indigo-100 text-indigo-700" },
  experience: { bg: "from-emerald-500 to-teal-600", light: "bg-emerald-50", border: "border-emerald-200", text: "text-emerald-700", badge: "bg-emerald-100 text-emerald-700" },
  skills: { bg: "from-amber-500 to-orange-500", light: "bg-amber-50", border: "border-amber-200", text: "text-amber-700", badge: "bg-amber-100 text-amber-700" },
  interests: { bg: "from-pink-500 to-rose-500", light: "bg-pink-50", border: "border-pink-200", text: "text-pink-700", badge: "bg-pink-100 text-pink-700" },
};

function SectionCard({
  title, icon: Icon, style, count, children, defaultOpen = true
}: {
  title: string;
  icon: React.ComponentType<{ className?: string }>;
  style: typeof sectionStyles.personal;
  count?: number;
  children: React.ReactNode;
  defaultOpen?: boolean;
}) {
  const [open, setOpen] = useState(defaultOpen);

  return (
    <div className="rounded-2xl overflow-hidden shadow-md border border-white/60 bg-white/95">
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className={`w-full flex items-center justify-between px-5 py-4 bg-gradient-to-r ${style.bg} text-white hover:opacity-95 transition-opacity`}
      >
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center">
            <Icon className="size-4" />
          </div>
          <span className="font-semibold text-sm">{title}</span>
          {count !== undefined && count > 0 && (
            <span className="bg-white/25 text-white text-xs px-2 py-0.5 rounded-full">
              {count}
            </span>
          )}
        </div>
        {open ? <ChevronUp className="size-4 opacity-80" /> : <ChevronDown className="size-4 opacity-80" />}
      </button>

      {open && (
        <div className="p-5 space-y-4">
          {children}
        </div>
      )}
    </div>
  );
}

function FieldGroup({ children }: { children: React.ReactNode }) {
  return <div className="grid md:grid-cols-2 gap-4">{children}</div>;
}

function Field({ label, required, error, children }: { label: string; required?: boolean; error?: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <label className="text-sm font-medium text-gray-700 flex items-center gap-1">
        {label}
        {required && <span className="text-red-500">*</span>}
      </label>
      {children}
      {error && (
        <p className="text-xs text-red-500 flex items-center gap-1">
          <span className="w-1 h-1 rounded-full bg-red-500 inline-block"></span>
          {error}
        </p>
      )}
    </div>
  );
}

function EntryCard({ onDelete, style, children }: {
  onDelete: () => void;
  style: typeof sectionStyles.education;
  children: React.ReactNode;
}) {
  return (
    <div className={`rounded-xl border ${style.border} ${style.light} p-4 space-y-3 relative`}>
      <button
        type="button"
        onClick={onDelete}
        className="absolute top-3 right-3 w-7 h-7 rounded-lg bg-red-100 text-red-500 hover:bg-red-500 hover:text-white transition-all flex items-center justify-center"
      >
        <Trash2 className="size-3.5" />
      </button>
      {children}
    </div>
  );
}

function AddButton({ onClick, label, style }: { onClick: () => void; label: string; style: typeof sectionStyles.education }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`w-full flex items-center justify-center gap-2 py-3 rounded-xl border-2 border-dashed ${style.border} ${style.text} hover:${style.light} transition-all text-sm font-medium hover:opacity-80`}
    >
      <Plus className="size-4" />
      {label}
    </button>
  );
}

export function CVForm({ initialData, onChange }: CVFormProps) {
  const [cvData, setCvData] = useState<CVData>(initialData);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const updateData = (newData: Partial<CVData>) => {
    const updated = { ...cvData, ...newData };
    setCvData(updated);
    onChange(updated);
  };

  const updatePersonalInfo = (field: string, value: string) => {
    const updated = { ...cvData, personalInfo: { ...cvData.personalInfo, [field]: value } };
    setCvData(updated);
    onChange(updated);

    let error: string | null = null;
    if (field === "email") error = getEmailError(value);
    else if (field === "phone") error = getPhoneError(value);
    else if (field === "password") error = getPasswordError(value);
    else if (field === "fullName") error = getRequiredError("Le nom complet", value);

    if (error) setErrors({ ...errors, [field]: error });
    else { const e = { ...errors }; delete e[field]; setErrors(e); }
  };

  // Education
  const addEducation = () => updateData({ education: [...cvData.education, { id: Date.now().toString(), degree: "", institution: "", startDate: "", endDate: "", description: "" }] });
  const updateEducation = (id: string, field: keyof Education, value: string) =>
    updateData({ education: cvData.education.map(e => e.id === id ? { ...e, [field]: value } : e) });
  const deleteEducation = (id: string) => updateData({ education: cvData.education.filter(e => e.id !== id) });

  // Experience
  const addExperience = () => updateData({ experience: [...cvData.experience, { id: Date.now().toString(), position: "", company: "", startDate: "", endDate: "", current: false, description: "" }] });
  const updateExperience = (id: string, field: keyof Experience, value: string | boolean) =>
    updateData({ experience: cvData.experience.map(e => e.id === id ? { ...e, [field]: value } : e) });
  const deleteExperience = (id: string) => updateData({ experience: cvData.experience.filter(e => e.id !== id) });

  // Skills
  const addSkill = () => updateData({ skills: [...cvData.skills, { id: Date.now().toString(), name: "", level: "Débutant" }] });
  const updateSkill = (id: string, field: keyof Skill, value: string) =>
    updateData({ skills: cvData.skills.map(s => s.id === id ? { ...s, [field]: value } : s) });
  const deleteSkill = (id: string) => updateData({ skills: cvData.skills.filter(s => s.id !== id) });

  // Interests
  const addInterest = () => updateData({ interests: [...cvData.interests, { id: Date.now().toString(), name: "" }] });
  const updateInterest = (id: string, value: string) =>
    updateData({ interests: cvData.interests.map(i => i.id === id ? { ...i, name: value } : i) });
  const deleteInterest = (id: string) => updateData({ interests: cvData.interests.filter(i => i.id !== id) });

  return (
    <div className="space-y-4">
      {/* Personal Info */}
      <SectionCard title="Informations Personnelles" icon={User} style={sectionStyles.personal} defaultOpen>
        <Field label="Nom Complet" required error={errors.fullName}>
          <div className="relative">
            <User className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-gray-400" />
            <Input
              value={cvData.personalInfo.fullName}
              onChange={(e) => updatePersonalInfo("fullName", e.target.value)}
              placeholder="Ex: Amadou Diallo"
              className="pl-10"
            />
          </div>
        </Field>

        <FieldGroup>
          <Field label="Email" required error={errors.email}>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-gray-400" />
              <Input
                type="email"
                value={cvData.personalInfo.email}
                onChange={(e) => updatePersonalInfo("email", e.target.value)}
                placeholder="exemple@email.com"
                className="pl-10"
              />
            </div>
          </Field>
          <Field label="Téléphone (Sénégal)" required error={errors.phone}>
            <div className="relative">
              <Phone className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-gray-400" />
              <Input
                value={cvData.personalInfo.phone}
                onChange={(e) => updatePersonalInfo("phone", e.target.value)}
                placeholder="77 123 45 67"
                className="pl-10"
              />
            </div>
          </Field>
        </FieldGroup>

        <Field label="Mot de passe" required error={errors.password}>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-gray-400" />
            <Input
              type="password"
              value={cvData.personalInfo.password}
              onChange={(e) => updatePersonalInfo("password", e.target.value)}
              placeholder="Minimum 6 caractères"
              className="pl-10"
            />
          </div>
        </Field>

        <Field label="Adresse">
          <div className="relative">
            <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-gray-400" />
            <Input
              value={cvData.personalInfo.address}
              onChange={(e) => updatePersonalInfo("address", e.target.value)}
              placeholder="Dakar, Sénégal"
              className="pl-10"
            />
          </div>
        </Field>

        <FieldGroup>
          <Field label="LinkedIn">
            <div className="relative">
              <Linkedin className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-gray-400" />
              <Input
                value={cvData.personalInfo.linkedin || ""}
                onChange={(e) => updatePersonalInfo("linkedin", e.target.value)}
                placeholder="linkedin.com/in/username"
                className="pl-10"
              />
            </div>
          </Field>
          <Field label="Site Web">
            <div className="relative">
              <Globe className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-gray-400" />
              <Input
                value={cvData.personalInfo.website || ""}
                onChange={(e) => updatePersonalInfo("website", e.target.value)}
                placeholder="www.monsite.com"
                className="pl-10"
              />
            </div>
          </Field>
        </FieldGroup>
      </SectionCard>

      {/* Education */}
      <SectionCard title="Formation" icon={GraduationCap} style={sectionStyles.education} count={cvData.education.length} defaultOpen>
        {cvData.education.map((edu) => (
          <EntryCard key={edu.id} onDelete={() => deleteEducation(edu.id)} style={sectionStyles.education}>
            <Field label="Diplôme" required>
              <Input value={edu.degree} onChange={(e) => updateEducation(edu.id, "degree", e.target.value)} placeholder="Ex: Master en Informatique" />
            </Field>
            <Field label="Institution" required>
              <Input value={edu.institution} onChange={(e) => updateEducation(edu.id, "institution", e.target.value)} placeholder="Ex: Université Cheikh Anta Diop" />
            </Field>
            <FieldGroup>
              <Field label="Date de début">
                <Input type="month" value={edu.startDate} onChange={(e) => updateEducation(edu.id, "startDate", e.target.value)} />
              </Field>
              <Field label="Date de fin">
                <Input type="month" value={edu.endDate} onChange={(e) => updateEducation(edu.id, "endDate", e.target.value)} />
              </Field>
            </FieldGroup>
            <Field label="Description">
              <Textarea value={edu.description} onChange={(e) => updateEducation(edu.id, "description", e.target.value)} placeholder="Mention, spécialisation..." rows={2} />
            </Field>
          </EntryCard>
        ))}
        <AddButton onClick={addEducation} label="Ajouter une formation" style={sectionStyles.education} />
      </SectionCard>

      {/* Experience */}
      <SectionCard title="Expériences Professionnelles" icon={Briefcase} style={sectionStyles.experience} count={cvData.experience.length} defaultOpen>
        {cvData.experience.map((exp) => (
          <EntryCard key={exp.id} onDelete={() => deleteExperience(exp.id)} style={sectionStyles.experience}>
            <Field label="Poste" required>
              <Input value={exp.position} onChange={(e) => updateExperience(exp.id, "position", e.target.value)} placeholder="Ex: Développeur Full Stack" />
            </Field>
            <Field label="Entreprise" required>
              <Input value={exp.company} onChange={(e) => updateExperience(exp.id, "company", e.target.value)} placeholder="Ex: Orange Sénégal" />
            </Field>
            <FieldGroup>
              <Field label="Date de début">
                <Input type="month" value={exp.startDate} onChange={(e) => updateExperience(exp.id, "startDate", e.target.value)} />
              </Field>
              <Field label="Date de fin">
                <Input type="month" value={exp.endDate} onChange={(e) => updateExperience(exp.id, "endDate", e.target.value)} disabled={exp.current} />
              </Field>
            </FieldGroup>
            <div className="flex items-center gap-2 py-1">
              <Checkbox id={`curr-${exp.id}`} checked={exp.current} onCheckedChange={(c) => updateExperience(exp.id, "current", c as boolean)} />
              <label htmlFor={`curr-${exp.id}`} className="text-sm text-gray-600 cursor-pointer">Je travaille actuellement ici</label>
            </div>
            <Field label="Description" required>
              <Textarea value={exp.description} onChange={(e) => updateExperience(exp.id, "description", e.target.value)} placeholder="Décrivez vos responsabilités et réalisations..." rows={3} />
            </Field>
          </EntryCard>
        ))}
        <AddButton onClick={addExperience} label="Ajouter une expérience" style={sectionStyles.experience} />
      </SectionCard>

      {/* Skills */}
      <SectionCard title="Compétences" icon={Award} style={sectionStyles.skills} count={cvData.skills.length} defaultOpen>
        <div className="space-y-2">
          {cvData.skills.map((skill) => (
            <div key={skill.id} className={`flex gap-2 items-center p-3 rounded-xl ${sectionStyles.skills.light} border ${sectionStyles.skills.border}`}>
              <Input
                value={skill.name}
                onChange={(e) => updateSkill(skill.id, "name", e.target.value)}
                placeholder="Ex: JavaScript, React..."
                className="flex-1 bg-white"
              />
              <Select value={skill.level} onValueChange={(v) => updateSkill(skill.id, "level", v)}>
                <SelectTrigger className="w-36 bg-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Débutant">🌱 Débutant</SelectItem>
                  <SelectItem value="Intermédiaire">📈 Intermédiaire</SelectItem>
                  <SelectItem value="Avancé">⚡ Avancé</SelectItem>
                  <SelectItem value="Expert">🏆 Expert</SelectItem>
                </SelectContent>
              </Select>
              <button
                type="button"
                onClick={() => deleteSkill(skill.id)}
                className="w-8 h-8 rounded-lg bg-red-100 text-red-500 hover:bg-red-500 hover:text-white transition-all flex items-center justify-center flex-shrink-0"
              >
                <Trash2 className="size-3.5" />
              </button>
            </div>
          ))}
        </div>
        <AddButton onClick={addSkill} label="Ajouter une compétence" style={sectionStyles.skills} />
      </SectionCard>

      {/* Interests */}
      <SectionCard title="Centres d'Intérêt" icon={Heart} style={sectionStyles.interests} count={cvData.interests.length} defaultOpen>
        <div className="flex flex-wrap gap-2">
          {cvData.interests.map((interest) => (
            <div key={interest.id} className={`flex items-center gap-1 ${sectionStyles.interests.light} border ${sectionStyles.interests.border} rounded-full px-3 py-1.5`}>
              <Input
                value={interest.name}
                onChange={(e) => updateInterest(interest.id, e.target.value)}
                placeholder="Ex: Lecture..."
                className="border-0 bg-transparent p-0 h-auto w-28 text-sm focus-visible:ring-0"
              />
              <button
                type="button"
                onClick={() => deleteInterest(interest.id)}
                className="text-red-400 hover:text-red-600 transition-colors ml-1"
              >
                <Trash2 className="size-3" />
              </button>
            </div>
          ))}
        </div>
        <AddButton onClick={addInterest} label="Ajouter un centre d'intérêt" style={sectionStyles.interests} />
      </SectionCard>
    </div>
  );
}