import { CVData } from "../../types/cv.types";
import { Mail, Phone, MapPin, Linkedin, Globe } from "lucide-react";

interface ClassicTemplateProps {
  data: CVData;
}

function formatDate(dateStr: string) {
  if (!dateStr) return "";
  const [year, month] = dateStr.split("-");
  const months = ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"];
  return `${months[parseInt(month) - 1]} ${year}`;
}

const levelDots: Record<string, number> = {
  "Débutant": 1,
  "Intermédiaire": 2,
  "Avancé": 3,
  "Expert": 4,
};

export function ClassicTemplate({ data }: ClassicTemplateProps) {
  return (
    <div id="cv-content" style={{ fontFamily: "Georgia, 'Times New Roman', serif", background: "#fff", minHeight: "297mm" }}>
      {/* Header */}
      <div style={{ borderBottom: "3px solid #1e293b", padding: "32px 40px 24px" }}>
        <h1 style={{
          margin: 0,
          fontSize: "2rem",
          fontWeight: 700,
          color: "#0f172a",
          letterSpacing: "-0.5px",
          textAlign: "center"
        }}>
          {data.personalInfo.fullName || "Votre Nom"}
        </h1>

        {/* Separator line */}
        <div style={{ textAlign: "center", margin: "10px 0" }}>
          <div style={{ display: "inline-flex", alignItems: "center", gap: 8 }}>
            <div style={{ width: 40, height: 1, background: "#94a3b8" }} />
            <div style={{ width: 6, height: 6, borderRadius: "50%", background: "#1e293b" }} />
            <div style={{ width: 40, height: 1, background: "#94a3b8" }} />
          </div>
        </div>

        {/* Contact row */}
        <div style={{ display: "flex", justifyContent: "center", flexWrap: "wrap", gap: "8px 20px", marginTop: 8 }}>
          {data.personalInfo.phone && (
            <span style={{ display: "flex", alignItems: "center", gap: 5, fontSize: "0.78rem", color: "#475569" }}>
              <Phone size={12} color="#64748b" />
              {data.personalInfo.phone}
            </span>
          )}
          {data.personalInfo.email && (
            <span style={{ display: "flex", alignItems: "center", gap: 5, fontSize: "0.78rem", color: "#475569" }}>
              <Mail size={12} color="#64748b" />
              {data.personalInfo.email}
            </span>
          )}
          {data.personalInfo.address && (
            <span style={{ display: "flex", alignItems: "center", gap: 5, fontSize: "0.78rem", color: "#475569" }}>
              <MapPin size={12} color="#64748b" />
              {data.personalInfo.address}
            </span>
          )}
          {data.personalInfo.linkedin && (
            <span style={{ display: "flex", alignItems: "center", gap: 5, fontSize: "0.78rem", color: "#475569" }}>
              <Linkedin size={12} color="#64748b" />
              {data.personalInfo.linkedin}
            </span>
          )}
          {data.personalInfo.website && (
            <span style={{ display: "flex", alignItems: "center", gap: 5, fontSize: "0.78rem", color: "#475569" }}>
              <Globe size={12} color="#64748b" />
              {data.personalInfo.website}
            </span>
          )}
        </div>
      </div>

      {/* Body */}
      <div style={{ padding: "28px 40px" }}>
        {/* Experience */}
        {data.experience.length > 0 && (
          <section style={{ marginBottom: 26 }}>
            <SectionTitle label="EXPÉRIENCES PROFESSIONNELLES" />
            <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
              {data.experience.map((exp) => (
                <div key={exp.id}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", flexWrap: "wrap", gap: 4 }}>
                    <div>
                      <span style={{ fontSize: "0.9rem", fontWeight: 700, color: "#0f172a" }}>{exp.position}</span>
                      {exp.company && (
                        <span style={{ fontSize: "0.82rem", color: "#475569", marginLeft: 8, fontStyle: "italic" }}>— {exp.company}</span>
                      )}
                    </div>
                    <span style={{ fontSize: "0.75rem", color: "#64748b", whiteSpace: "nowrap" }}>
                      {formatDate(exp.startDate)}{exp.startDate ? " – " : ""}{exp.current ? "Présent" : formatDate(exp.endDate)}
                    </span>
                  </div>
                  {exp.description && (
                    <p style={{ margin: "5px 0 0", fontSize: "0.78rem", color: "#475569", lineHeight: 1.7, paddingLeft: 12, borderLeft: "2px solid #e2e8f0" }}>
                      {exp.description}
                    </p>
                  )}
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Education */}
        {data.education.length > 0 && (
          <section style={{ marginBottom: 26 }}>
            <SectionTitle label="FORMATION" />
            <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
              {data.education.map((edu) => (
                <div key={edu.id}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", flexWrap: "wrap", gap: 4 }}>
                    <div>
                      <span style={{ fontSize: "0.88rem", fontWeight: 700, color: "#0f172a" }}>{edu.degree}</span>
                      {edu.institution && (
                        <span style={{ fontSize: "0.8rem", color: "#475569", marginLeft: 8, fontStyle: "italic" }}>— {edu.institution}</span>
                      )}
                    </div>
                    <span style={{ fontSize: "0.75rem", color: "#64748b", whiteSpace: "nowrap" }}>
                      {formatDate(edu.startDate)}{edu.startDate ? " – " : ""}{formatDate(edu.endDate)}
                    </span>
                  </div>
                  {edu.description && (
                    <p style={{ margin: "5px 0 0", fontSize: "0.76rem", color: "#475569", lineHeight: 1.6, paddingLeft: 12, borderLeft: "2px solid #e2e8f0" }}>
                      {edu.description}
                    </p>
                  )}
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Two columns: Skills + Interests */}
        {(data.skills.length > 0 || data.interests.length > 0) && (
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 32 }}>
            {data.skills.length > 0 && (
              <section>
                <SectionTitle label="COMPÉTENCES" />
                <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                  {data.skills.map((skill) => (
                    <div key={skill.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                      <span style={{ fontSize: "0.78rem", color: "#374151" }}>{skill.name}</span>
                      <div style={{ display: "flex", gap: 3 }}>
                        {[1, 2, 3, 4].map((dot) => (
                          <div key={dot} style={{
                            width: 8,
                            height: 8,
                            borderRadius: "50%",
                            background: dot <= (levelDots[skill.level] || 2) ? "#1e293b" : "#e2e8f0",
                            border: "1px solid #cbd5e1"
                          }} />
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {data.interests.length > 0 && (
              <section>
                <SectionTitle label="CENTRES D'INTÉRÊT" />
                <div style={{ display: "flex", flexDirection: "column", gap: 5 }}>
                  {data.interests.map((interest, idx) => (
                    <div key={interest.id} style={{ display: "flex", alignItems: "center", gap: 8 }}>
                      <div style={{ width: 4, height: 4, borderRadius: "50%", background: "#64748b", flexShrink: 0 }} />
                      <span style={{ fontSize: "0.78rem", color: "#475569" }}>{interest.name}</span>
                    </div>
                  ))}
                </div>
              </section>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function SectionTitle({ label }: { label: string }) {
  return (
    <div style={{ marginBottom: 12 }}>
      <h2 style={{ margin: 0, fontSize: "0.7rem", fontWeight: 700, letterSpacing: "0.12em", color: "#334155", fontFamily: "'Segoe UI', system-ui, sans-serif" }}>
        {label}
      </h2>
      <div style={{ height: 1.5, background: "#1e293b", marginTop: 5, borderRadius: 1 }} />
    </div>
  );
}
