import { CVData } from "../../types/cv.types";
import { Mail, Phone, MapPin, Linkedin, Globe } from "lucide-react";

interface ModernTemplateProps {
  data: CVData;
}

const levelToPercent: Record<string, number> = {
  "Débutant": 25,
  "Intermédiaire": 50,
  "Avancé": 75,
  "Expert": 100,
};

const levelToColor: Record<string, string> = {
  "Débutant": "#94a3b8",
  "Intermédiaire": "#60a5fa",
  "Avancé": "#818cf8",
  "Expert": "#8b5cf6",
};

function formatDate(dateStr: string) {
  if (!dateStr) return "";
  const [year, month] = dateStr.split("-");
  const months = ["Jan", "Fév", "Mar", "Avr", "Mai", "Jun", "Jul", "Aoû", "Sep", "Oct", "Nov", "Déc"];
  return `${months[parseInt(month) - 1]} ${year}`;
}

export function ModernTemplate({ data }: ModernTemplateProps) {
  return (
    <div id="cv-content" style={{ fontFamily: "'Segoe UI', system-ui, sans-serif", background: "#fff", minHeight: "297mm" }}>
      {/* Header with gradient */}
      <div style={{
        background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
        padding: "36px 40px 28px",
        color: "#fff",
        position: "relative",
        overflow: "hidden"
      }}>
        {/* Decorative circles */}
        <div style={{ position: "absolute", top: -40, right: -40, width: 160, height: 160, borderRadius: "50%", background: "rgba(255,255,255,0.08)" }} />
        <div style={{ position: "absolute", bottom: -20, right: 80, width: 80, height: 80, borderRadius: "50%", background: "rgba(255,255,255,0.06)" }} />

        <h1 style={{ margin: 0, fontSize: "2rem", fontWeight: 700, letterSpacing: "-0.5px", lineHeight: 1.1 }}>
          {data.personalInfo.fullName || "Votre Nom"}
        </h1>

        <div style={{ marginTop: 16, display: "flex", flexWrap: "wrap", gap: "12px 20px" }}>
          {data.personalInfo.email && (
            <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: "0.8rem", opacity: 0.9 }}>
              <Mail size={13} />
              <span>{data.personalInfo.email}</span>
            </div>
          )}
          {data.personalInfo.phone && (
            <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: "0.8rem", opacity: 0.9 }}>
              <Phone size={13} />
              <span>{data.personalInfo.phone}</span>
            </div>
          )}
          {data.personalInfo.address && (
            <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: "0.8rem", opacity: 0.9 }}>
              <MapPin size={13} />
              <span>{data.personalInfo.address}</span>
            </div>
          )}
          {data.personalInfo.linkedin && (
            <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: "0.8rem", opacity: 0.9 }}>
              <Linkedin size={13} />
              <span>{data.personalInfo.linkedin}</span>
            </div>
          )}
          {data.personalInfo.website && (
            <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: "0.8rem", opacity: 0.9 }}>
              <Globe size={13} />
              <span>{data.personalInfo.website}</span>
            </div>
          )}
        </div>
      </div>

      {/* Body: two columns */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 2fr", minHeight: "calc(297mm - 120px)" }}>
        {/* Left sidebar */}
        <div style={{ background: "#f8f9ff", padding: "28px 24px", borderRight: "1px solid #e8ecff" }}>
          {/* Skills */}
          {data.skills.length > 0 && (
            <div style={{ marginBottom: 28 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 16 }}>
                <div style={{ width: 3, height: 18, background: "linear-gradient(180deg, #667eea, #764ba2)", borderRadius: 2 }} />
                <span style={{ fontSize: "0.75rem", fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase", color: "#667eea" }}>Compétences</span>
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                {data.skills.map((skill) => (
                  <div key={skill.id}>
                    <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                      <span style={{ fontSize: "0.78rem", fontWeight: 500, color: "#374151" }}>{skill.name}</span>
                      <span style={{ fontSize: "0.68rem", color: levelToColor[skill.level] || "#667eea", fontWeight: 600 }}>{skill.level}</span>
                    </div>
                    <div style={{ height: 4, background: "#e2e8f0", borderRadius: 4, overflow: "hidden" }}>
                      <div style={{
                        height: "100%",
                        width: `${levelToPercent[skill.level] || 50}%`,
                        background: `linear-gradient(90deg, #667eea, ${levelToColor[skill.level] || "#764ba2"})`,
                        borderRadius: 4,
                        transition: "width 0.5s ease"
                      }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Interests */}
          {data.interests.length > 0 && (
            <div>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 14 }}>
                <div style={{ width: 3, height: 18, background: "linear-gradient(180deg, #f093fb, #f5576c)", borderRadius: 2 }} />
                <span style={{ fontSize: "0.75rem", fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase", color: "#e879f9" }}>Centres d'Intérêt</span>
              </div>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                {data.interests.map((interest) => (
                  <span key={interest.id} style={{
                    background: "linear-gradient(135deg, #fdf2ff, #fce7f3)",
                    border: "1px solid #f0abfc",
                    color: "#a21caf",
                    fontSize: "0.72rem",
                    padding: "3px 10px",
                    borderRadius: 20,
                    fontWeight: 500
                  }}>
                    {interest.name}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right main content */}
        <div style={{ padding: "28px 32px" }}>
          {/* Experience */}
          {data.experience.length > 0 && (
            <div style={{ marginBottom: 28 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 18 }}>
                <div style={{ width: 3, height: 20, background: "linear-gradient(180deg, #10b981, #059669)", borderRadius: 2 }} />
                <span style={{ fontSize: "0.75rem", fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase", color: "#10b981" }}>Expériences Professionnelles</span>
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>
                {data.experience.map((exp, i) => (
                  <div key={exp.id} style={{ paddingLeft: 16, borderLeft: "2px solid #d1fae5", position: "relative" }}>
                    <div style={{ position: "absolute", left: -5, top: 4, width: 8, height: 8, borderRadius: "50%", background: "#10b981", border: "2px solid #fff" }} />
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 4 }}>
                      <div>
                        <div style={{ fontSize: "0.9rem", fontWeight: 700, color: "#111827" }}>{exp.position}</div>
                        <div style={{ fontSize: "0.8rem", color: "#10b981", fontWeight: 600, marginTop: 2 }}>{exp.company}</div>
                      </div>
                      <span style={{
                        fontSize: "0.7rem",
                        background: "#d1fae5",
                        color: "#065f46",
                        padding: "2px 8px",
                        borderRadius: 20,
                        fontWeight: 500,
                        whiteSpace: "nowrap"
                      }}>
                        {formatDate(exp.startDate)} – {exp.current ? "Présent" : formatDate(exp.endDate)}
                      </span>
                    </div>
                    {exp.description && (
                      <p style={{ fontSize: "0.78rem", color: "#6b7280", marginTop: 6, lineHeight: 1.6, margin: "6px 0 0" }}>{exp.description}</p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Education */}
          {data.education.length > 0 && (
            <div>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 18 }}>
                <div style={{ width: 3, height: 20, background: "linear-gradient(180deg, #3b82f6, #2563eb)", borderRadius: 2 }} />
                <span style={{ fontSize: "0.75rem", fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase", color: "#3b82f6" }}>Formation</span>
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
                {data.education.map((edu) => (
                  <div key={edu.id} style={{ paddingLeft: 16, borderLeft: "2px solid #dbeafe", position: "relative" }}>
                    <div style={{ position: "absolute", left: -5, top: 4, width: 8, height: 8, borderRadius: "50%", background: "#3b82f6", border: "2px solid #fff" }} />
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 4 }}>
                      <div>
                        <div style={{ fontSize: "0.88rem", fontWeight: 700, color: "#111827" }}>{edu.degree}</div>
                        <div style={{ fontSize: "0.78rem", color: "#3b82f6", fontWeight: 600, marginTop: 2 }}>{edu.institution}</div>
                      </div>
                      <span style={{
                        fontSize: "0.7rem",
                        background: "#dbeafe",
                        color: "#1e40af",
                        padding: "2px 8px",
                        borderRadius: 20,
                        fontWeight: 500,
                        whiteSpace: "nowrap"
                      }}>
                        {formatDate(edu.startDate)} – {formatDate(edu.endDate)}
                      </span>
                    </div>
                    {edu.description && (
                      <p style={{ fontSize: "0.76rem", color: "#6b7280", marginTop: 6, lineHeight: 1.6, margin: "6px 0 0" }}>{edu.description}</p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
