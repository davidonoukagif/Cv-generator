import { useForm } from "react-hook-form";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";

export interface HomeworkData {
  id: string;
  title: string;
  subject: string;
  deadline: string;
  description: string;
  priority: string;
  fileName?: string;
  submittedAt: string;
}

interface HomeworkFormProps {
  onSubmit: (data: HomeworkData) => void;
}

export function HomeworkForm({ onSubmit }: HomeworkFormProps) {
  const { register, handleSubmit, reset, setValue, watch } = useForm();
  const fileInput = watch("file");

  const onFormSubmit = (data: any) => {
    const fileName = data.file?.[0]?.name;
    const homeworkData: HomeworkData = {
      id: Date.now().toString(),
      title: data.title,
      subject: data.subject,
      deadline: data.deadline,
      description: data.description,
      priority: data.priority,
      fileName: fileName,
      submittedAt: new Date().toLocaleString("fr-FR"),
    };
    onSubmit(homeworkData);
    reset();
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Soumettre un devoir</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit(onFormSubmit)} className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="title">Titre du devoir *</Label>
              <Input
                id="title"
                {...register("title", { required: true })}
                placeholder="Ex: Exercices de mathématiques"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="subject">Matière *</Label>
              <Select onValueChange={(value) => setValue("subject", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Sélectionnez une matière" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="mathematiques">Mathématiques</SelectItem>
                  <SelectItem value="francais">Français</SelectItem>
                  <SelectItem value="anglais">Anglais</SelectItem>
                  <SelectItem value="histoire">Histoire</SelectItem>
                  <SelectItem value="sciences">Sciences</SelectItem>
                  <SelectItem value="informatique">Informatique</SelectItem>
                  <SelectItem value="autre">Autre</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="deadline">Date limite *</Label>
              <Input
                id="deadline"
                type="date"
                {...register("deadline", { required: true })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="priority">Priorité *</Label>
              <Select onValueChange={(value) => setValue("priority", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Sélectionnez la priorité" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="haute">Haute</SelectItem>
                  <SelectItem value="moyenne">Moyenne</SelectItem>
                  <SelectItem value="basse">Basse</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              {...register("description")}
              placeholder="Décrivez le devoir..."
              rows={4}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="file">Fichier à joindre</Label>
            <Input id="file" type="file" {...register("file")} />
            {fileInput?.[0] && (
              <p className="text-sm text-muted-foreground">
                Fichier sélectionné: {fileInput[0].name}
              </p>
            )}
          </div>

          <Button type="submit" className="w-full">
            Soumettre le devoir
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
