import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "./ui/table";
import { Button } from "./ui/button";
import { FileText, Trash2 } from "lucide-react";
import type { HomeworkData } from "./homework-form";

interface HomeworkListProps {
  homework: HomeworkData[];
  onDelete: (id: string) => void;
}

export function HomeworkList({ homework, onDelete }: HomeworkListProps) {
  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "haute":
        return "destructive";
      case "moyenne":
        return "default";
      case "basse":
        return "secondary";
      default:
        return "default";
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Devoirs soumis ({homework.length})</CardTitle>
      </CardHeader>
      <CardContent>
        {homework.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <FileText className="mx-auto size-12 mb-2 opacity-50" />
            <p>Aucun devoir soumis pour le moment</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Titre</TableHead>
                  <TableHead>Matière</TableHead>
                  <TableHead>Date limite</TableHead>
                  <TableHead>Priorité</TableHead>
                  <TableHead>Fichier</TableHead>
                  <TableHead>Soumis le</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {homework.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell className="font-medium">{item.title}</TableCell>
                    <TableCell className="capitalize">{item.subject}</TableCell>
                    <TableCell>
                      {new Date(item.deadline).toLocaleDateString("fr-FR")}
                    </TableCell>
                    <TableCell>
                      <Badge variant={getPriorityColor(item.priority)}>
                        {item.priority}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {item.fileName ? (
                        <span className="text-sm flex items-center gap-1">
                          <FileText className="size-4" />
                          {item.fileName}
                        </span>
                      ) : (
                        <span className="text-muted-foreground text-sm">
                          Aucun
                        </span>
                      )}
                    </TableCell>
                    <TableCell className="text-sm">
                      {item.submittedAt}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onDelete(item.id)}
                      >
                        <Trash2 className="size-4 text-destructive" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
