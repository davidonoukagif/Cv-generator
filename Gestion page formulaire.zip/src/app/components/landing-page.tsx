import { useState } from "react";
import { FileText, Linkedin, Upload, ChevronRight, Star, Users, Download, Check, ArrowRight, Sparkles } from "lucide-react";
import type { CVData, TemplateType } from "../types/cv.types";
import { ModernTemplate } from "./cv-templates/modern-template";
import { ClassicTemplate } from "./cv-templates/classic-template";

interface LandingPageProps {
  onStart: () => void;
  cvData: CVData;
  selectedTemplate: TemplateType;
}

const DEMO_DATA: CVData = {
  personalInfo: {
    fullName: "Aminata Diallo",
    email: "aminata.diallo@gmail.com",
    phone: "77 456 78 90",
    address: "Dakar, Sénégal",
    linkedin: "linkedin.com/in/aminata-diallo",
    website: "aminatadiallo.sn",
    password: "secret"
  },
  education: [
    { id: "1", degree: "Master en Marketing Digital", institution: "UCAD — Dakar", startDate: "2020-09", endDate: "2022-06", description: "Mention Très Bien" }
  ],
  experience: [
    { id: "1", position: "Chef de Projet Digital", company: "Orange Sénégal", startDate: "2022-07", endDate: "", current: true, description: "Pilotage de campagnes digitales, gestion d'équipes de 5 personnes." },
    { id: "2", position: "Chargée de Communication", company: "Sonatel", startDate: "2021-01", endDate: "2022-06", current: false, description: "Création de contenus et stratégie social media." }
  ],
  skills: [
    { id: "1", name: "Marketing Digital", level: "Expert" },
    { id: "2", name: "Adobe Suite", level: "Avancé" },
    { id: "3", name: "Google Analytics", level: "Avancé" },
    { id: "4", name: "Français / Anglais", level: "Expert" }
  ],
  interests: [
    { id: "1", name: "Entrepreneuriat" },
    { id: "2", name: "Photographie" },
    { id: "3", name: "Voyages" }
  ]
};

const stats = [
  { icon: Users, value: "12 000+", label: "CVs créés" },
  { icon: Download, value: "8 500+", label: "PDF exportés" },
  { icon: Star, value: "4.9/5", label: "Satisfaction" },
];

const features = [
  "Sauvegarde automatique dans votre navigateur",
  "2 templates professionnels (Moderne & Classique)",
  "Export PDF haute qualité",
  "Validation téléphone sénégalais",
  "100% gratuit, aucune inscription requise",
];

export function LandingPage({ onStart, cvData, selectedTemplate }: LandingPageProps) {
  const preview = (cvData.personalInfo.fullName || cvData.personalInfo.email) ? cvData : DEMO_DATA;

  return (
    <div style={{ fontFamily: "'Inter', system-ui, sans-serif", minHeight: "100vh", background: "linear-gradient(135deg, #fdf4ff 0%, #fef3c7 25%, #dbeafe 50%, #fce7f3 75%, #f0fdf4 100%)" }}>
      {/* Navbar */}
      <nav style={{
        background: "rgba(255,255,255,0.85)",
        backdropFilter: "blur(12px)",
        borderBottom: "1px solid rgba(99,102,241,0.1)",
        padding: "0 40px",
        height: 64,
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        position: "sticky",
        top: 0,
        zIndex: 100,
        boxShadow: "0 4px 20px rgba(99,102,241,0.15)"
      }}>
        {/* Logo */}
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{
            width: 36, height: 36, borderRadius: 10,
            background: "linear-gradient(135deg, #ec4899, #8b5cf6, #06b6d4)",
            display: "flex", alignItems: "center", justifyContent: "center",
            boxShadow: "0 4px 16px rgba(139,92,246,0.5)",
            animation: "pulse 2s ease-in-out infinite"
          }}>
            <FileText size={18} color="#fff" />
          </div>
          <div>
            <span style={{ fontWeight: 800, fontSize: "1rem", background: "linear-gradient(135deg, #ec4899, #8b5cf6)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", letterSpacing: "-0.3px" }}>CV Pro</span>
            <span style={{ display: "block", fontSize: "0.65rem", color: "#f97316", marginTop: -2, letterSpacing: "0.04em", textTransform: "uppercase", fontWeight: 700 }}>Sénégal</span>
          </div>
        </div>

        {/* Nav links */}
        <div style={{ display: "flex", alignItems: "center", gap: 32 }} className="hidden-mobile">
          {[
            { name: "Templates", color: "#8b5cf6" },
            { name: "Fonctionnalités", color: "#06b6d4" },
            { name: "Tarifs", color: "#ec4899" },
            { name: "Guide", color: "#f97316" }
          ].map(link => (
            <a key={link.name} href="#" style={{ fontSize: "0.85rem", color: "#475569", textDecoration: "none", fontWeight: 600, transition: "all 0.2s" }}
              onMouseEnter={e => { e.currentTarget.style.color = link.color; e.currentTarget.style.transform = "translateY(-2px)"; }}
              onMouseLeave={e => { e.currentTarget.style.color = "#475569"; e.currentTarget.style.transform = "translateY(0)"; }}
            >{link.name}</a>
          ))}
        </div>

        {/* CTA */}
        <button
          onClick={onStart}
          style={{
            background: "linear-gradient(135deg, #ec4899, #8b5cf6, #06b6d4)",
            backgroundSize: "200% 200%",
            animation: "gradientShift 3s ease infinite",
            color: "#fff",
            border: "none",
            borderRadius: 12,
            padding: "11px 24px",
            fontSize: "0.85rem",
            fontWeight: 700,
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            gap: 6,
            boxShadow: "0 4px 20px rgba(139,92,246,0.5)",
            transition: "all 0.3s"
          }}
          onMouseEnter={e => { e.currentTarget.style.transform = "translateY(-2px)"; e.currentTarget.style.boxShadow = "0 8px 30px rgba(139,92,246,0.6)"; }}
          onMouseLeave={e => { e.currentTarget.style.transform = "translateY(0)"; e.currentTarget.style.boxShadow = "0 4px 20px rgba(139,92,246,0.5)"; }}
        >
          Créer mon CV
          <ArrowRight size={15} />
        </button>
      </nav>

      {/* Breadcrumb */}
      <div style={{ padding: "10px 40px", background: "rgba(255,255,255,0.5)", backdropFilter: "blur(8px)", borderBottom: "1px solid rgba(139,92,246,0.1)" }}>
        <span style={{ fontSize: "0.78rem", color: "#94a3b8" }}>Accueil</span>
        <span style={{ fontSize: "0.78rem", color: "#94a3b8", margin: "0 6px" }}>/</span>
        <span style={{ fontSize: "0.78rem", background: "linear-gradient(135deg, #ec4899, #8b5cf6)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", fontWeight: 700 }}>Créer un CV en ligne gratuit</span>
      </div>

      {/* Hero Section */}
      <section style={{
        background: "transparent",
        padding: "60px 40px 0",
        overflow: "hidden",
        position: "relative"
      }}>
        {/* Animated gradient orbs */}
        <div style={{
          position: "absolute",
          top: "10%",
          left: "5%",
          width: 300,
          height: 300,
          borderRadius: "50%",
          background: "radial-gradient(circle, rgba(139,92,246,0.3) 0%, transparent 70%)",
          filter: "blur(60px)",
          animation: "float 6s ease-in-out infinite"
        }} />
        <div style={{
          position: "absolute",
          top: "20%",
          right: "10%",
          width: 250,
          height: 250,
          borderRadius: "50%",
          background: "radial-gradient(circle, rgba(236,72,153,0.3) 0%, transparent 70%)",
          filter: "blur(60px)",
          animation: "float 8s ease-in-out infinite reverse"
        }} />
        <div style={{
          position: "absolute",
          bottom: "15%",
          left: "30%",
          width: 200,
          height: 200,
          borderRadius: "50%",
          background: "radial-gradient(circle, rgba(6,182,212,0.3) 0%, transparent 70%)",
          filter: "blur(60px)",
          animation: "float 7s ease-in-out infinite"
        }} />

        <div style={{ maxWidth: 1180, margin: "0 auto", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 60, alignItems: "flex-end", position: "relative", zIndex: 1 }}>
          {/* Left */}
          <div style={{ paddingBottom: 60 }}>
            <div style={{
              display: "inline-flex", alignItems: "center", gap: 6,
              background: "linear-gradient(135deg, rgba(236,72,153,0.15), rgba(139,92,246,0.15))",
              border: "2px solid rgba(236,72,153,0.3)",
              borderRadius: 24,
              padding: "6px 16px", fontSize: "0.75rem", fontWeight: 700,
              marginBottom: 20,
              boxShadow: "0 4px 16px rgba(236,72,153,0.2)",
              animation: "bounce 2s ease-in-out infinite"
            }}>
              <Sparkles size={14} style={{ color: "#ec4899" }} />
              <span style={{ background: "linear-gradient(135deg, #ec4899, #8b5cf6)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
                100% Gratuit · Aucune inscription
              </span>
            </div>

            <h1 style={{
              margin: "0 0 16px",
              fontSize: "3rem",
              fontWeight: 900,
              background: "linear-gradient(135deg, #ec4899, #8b5cf6, #06b6d4, #f97316)",
              backgroundSize: "200% 200%",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              lineHeight: 1.15,
              letterSpacing: "-1.5px",
              animation: "gradientShift 5s ease infinite"
            }}>
              Créez votre CV<br />
              professionnel en ligne
            </h1>

            <p style={{ margin: "0 0 32px", fontSize: "1.05rem", color: "#64748b", lineHeight: 1.7, maxWidth: 440 }}>
              Rédiger son CV n'a jamais été aussi <span style={{ fontWeight: 700, background: "linear-gradient(135deg, #ec4899, #8b5cf6)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>simple et amusant</span> !<br />
              Choisissez un template, remplissez vos informations et exportez en PDF en quelques minutes.
            </p>

            {/* Features list */}
            <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 36 }}>
              {features.map((f, i) => {
                const colors = ["#ec4899", "#8b5cf6", "#06b6d4", "#f97316", "#10b981"];
                const color = colors[i % colors.length];
                return (
                  <div key={i} style={{ display: "flex", alignItems: "center", gap: 10, animation: `slideInLeft 0.5s ease ${i * 0.1}s backwards` }}>
                    <div style={{ 
                      width: 22, height: 22, borderRadius: "50%", 
                      background: `linear-gradient(135deg, ${color}, ${color}dd)`, 
                      display: "flex", alignItems: "center", justifyContent: "center", 
                      flexShrink: 0,
                      boxShadow: `0 4px 12px ${color}40`
                    }}>
                      <Check size={12} color="#fff" strokeWidth={3} />
                    </div>
                    <span style={{ fontSize: "0.85rem", color: "#475569", fontWeight: 500 }}>{f}</span>
                  </div>
                );
              })}
            </div>

            {/* Action Cards */}
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              <ActionCard
                icon={FileText}
                title="Créer un nouveau CV"
                desc="Créez votre CV à partir de zéro, étape par étape"
                primary
                gradient="linear-gradient(135deg, #ec4899, #8b5cf6)"
                onClick={onStart}
              />
              <ActionCard
                icon={Linkedin}
                title="Importer mon profil LinkedIn"
                desc="Transformez votre profil LinkedIn en CV instantanément"
                gradient="linear-gradient(135deg, #06b6d4, #8b5cf6)"
                onClick={onStart}
              />
              <ActionCard
                icon={Upload}
                title="Importer un CV existant"
                desc="Téléchargez votre ancien CV et mettez-le à jour"
                gradient="linear-gradient(135deg, #f97316, #ec4899)"
                onClick={onStart}
              />
            </div>
          </div>

          {/* Right: CV Preview */}
          <div style={{ position: "relative", display: "flex", justifyContent: "center" }}>
            {/* Animated decorative rings */}
            <div style={{
              position: "absolute", top: 20, right: -20,
              width: 200, height: 200, borderRadius: "50%",
              background: "conic-gradient(from 0deg, #ec4899, #8b5cf6, #06b6d4, #ec4899)",
              opacity: 0.2,
              animation: "spin 10s linear infinite"
            }} />
            <div style={{
              position: "absolute", bottom: 60, left: -40,
              width: 160, height: 160, borderRadius: "50%",
              background: "conic-gradient(from 180deg, #f97316, #ec4899, #8b5cf6, #f97316)",
              opacity: 0.15,
              animation: "spin 15s linear infinite reverse"
            }} />

            {/* CV Card */}
            <div style={{
              width: 380,
              background: "#fff",
              borderRadius: 20,
              boxShadow: "0 30px 80px rgba(139,92,246,0.3), 0 0 0 1px rgba(139,92,246,0.1)",
              overflow: "hidden",
              transform: "perspective(1000px) rotateY(-3deg) rotateX(2deg)",
              transition: "transform 0.4s ease",
              position: "relative",
              zIndex: 2,
              border: "2px solid rgba(236,72,153,0.2)"
            }}
              onMouseEnter={e => (e.currentTarget.style.transform = "perspective(1000px) rotateY(0deg) rotateX(0deg) scale(1.03)")}
              onMouseLeave={e => (e.currentTarget.style.transform = "perspective(1000px) rotateY(-3deg) rotateX(2deg)")}
            >
              <div style={{ transform: "scale(0.72)", transformOrigin: "top left", width: "calc(100% / 0.72)", pointerEvents: "none" }}>
                <ModernTemplate data={preview} />
              </div>
              {/* Rainbow overlay gradient at bottom */}
              <div style={{
                position: "absolute", bottom: 0, left: 0, right: 0, height: 100,
                background: "linear-gradient(transparent, rgba(255,255,255,0.98))"
              }} />
            </div>

            {/* Floating badge */}
            <div style={{
              position: "absolute", top: 30, left: 10,
              background: "linear-gradient(135deg, #fff, #fef3c7)",
              borderRadius: 16, padding: "10px 16px",
              boxShadow: "0 8px 30px rgba(139,92,246,0.3)",
              display: "flex", alignItems: "center", gap: 10,
              zIndex: 3,
              border: "2px solid rgba(236,72,153,0.2)",
              animation: "float 3s ease-in-out infinite"
            }}>
              <div style={{ 
                width: 32, height: 32, borderRadius: 10, 
                background: "linear-gradient(135deg, #ec4899, #8b5cf6)", 
                display: "flex", alignItems: "center", justifyContent: "center",
                boxShadow: "0 4px 12px rgba(139,92,246,0.4)"
              }}>
                <Star size={16} color="#fff" fill="#fff" />
              </div>
              <div>
                <div style={{ fontSize: "0.75rem", fontWeight: 800, background: "linear-gradient(135deg, #ec4899, #8b5cf6)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
                  CV Professionnel
                </div>
                <div style={{ fontSize: "0.68rem", color: "#64748b", fontWeight: 600 }}>Export PDF en 1 clic</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats bar */}
      <div style={{
        background: "linear-gradient(135deg, #1e1b4b, #312e81, #1e293b)",
        padding: "24px 40px",
        display: "flex",
        justifyContent: "center",
        gap: 80,
        position: "relative",
        overflow: "hidden"
      }}>
        {/* Animated gradient overlay */}
        <div style={{
          position: "absolute",
          inset: 0,
          background: "linear-gradient(90deg, transparent, rgba(236,72,153,0.1), transparent)",
          animation: "shimmer 3s linear infinite"
        }} />
        
        {stats.map(({ icon: Icon, value, label }, i) => {
          const colors = ["#ec4899", "#8b5cf6", "#06b6d4"];
          const color = colors[i];
          return (
            <div key={label} style={{ display: "flex", alignItems: "center", gap: 14, position: "relative", zIndex: 1 }}>
              <div style={{ 
                width: 40, height: 40, borderRadius: 12, 
                background: `linear-gradient(135deg, ${color}30, ${color}10)`, 
                display: "flex", alignItems: "center", justifyContent: "center",
                border: `2px solid ${color}40`,
                boxShadow: `0 4px 16px ${color}30`
              }}>
                <Icon size={18} color={color} />
              </div>
              <div>
                <div style={{ fontSize: "1.2rem", fontWeight: 800, color: "#fff" }}>{value}</div>
                <div style={{ fontSize: "0.75rem", color: "#94a3b8", fontWeight: 500 }}>{label}</div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Templates showcase */}
      <section style={{ padding: "72px 40px", background: "transparent", position: "relative" }}>
        <div style={{ maxWidth: 1180, margin: "0 auto" }}>
          <div style={{ textAlign: "center", marginBottom: 48 }}>
            <div style={{ 
              display: "inline-flex", alignItems: "center", gap: 6, 
              background: "linear-gradient(135deg, rgba(236,72,153,0.1), rgba(139,92,246,0.1))", 
              border: "2px solid rgba(139,92,246,0.3)",
              borderRadius: 24, padding: "5px 16px", fontSize: "0.75rem", fontWeight: 700, marginBottom: 16,
              boxShadow: "0 4px 16px rgba(139,92,246,0.2)"
            }}>
              <span style={{ background: "linear-gradient(135deg, #ec4899, #8b5cf6)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
                Nos Templates
              </span>
            </div>
            <h2 style={{ 
              margin: "0 0 12px", fontSize: "2.2rem", fontWeight: 900, 
              background: "linear-gradient(135deg, #ec4899, #8b5cf6, #06b6d4)", 
              backgroundSize: "200% 200%",
              WebkitBackgroundClip: "text", 
              WebkitTextFillColor: "transparent", 
              letterSpacing: "-0.8px",
              animation: "gradientShift 5s ease infinite"
            }}>
              2 designs pensés pour impressionner
            </h2>
            <p style={{ margin: 0, color: "#64748b", fontSize: "0.95rem", fontWeight: 500 }}>Choisissez le template qui vous correspond le mieux</p>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 32 }}>
            {/* Modern */}
            <TemplateShowcase
              name="Template Moderne"
              desc="Design contemporain avec sidebar, barres de compétences et mise en page deux colonnes."
              badge="✨ Populaire"
              badgeGradient="linear-gradient(135deg, #ec4899, #8b5cf6)"
              onClick={onStart}
            >
              <div style={{ transform: "scale(0.55)", transformOrigin: "top left", width: "calc(100% / 0.55)", pointerEvents: "none" }}>
                <ModernTemplate data={DEMO_DATA} />
              </div>
            </TemplateShowcase>

            {/* Classic */}
            <TemplateShowcase
              name="Template Classique"
              desc="Mise en page traditionnelle et élégante, idéale pour les secteurs formels et académiques."
              badge="🏛 Élégant"
              badgeGradient="linear-gradient(135deg, #06b6d4, #8b5cf6)"
              onClick={onStart}
            >
              <div style={{ transform: "scale(0.55)", transformOrigin: "top left", width: "calc(100% / 0.55)", pointerEvents: "none" }}>
                <ClassicTemplate data={DEMO_DATA} />
              </div>
            </TemplateShowcase>
          </div>
        </div>
      </section>

      {/* CTA Banner */}
      <section style={{
        margin: "0 40px 60px",
        borderRadius: 24,
        background: "linear-gradient(135deg, #ec4899 0%, #8b5cf6 50%, #06b6d4 100%)",
        backgroundSize: "200% 200%",
        animation: "gradientShift 8s ease infinite",
        padding: "56px 60px",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        gap: 40,
        position: "relative",
        overflow: "hidden",
        boxShadow: "0 20px 60px rgba(139,92,246,0.4)"
      }}>
        {/* Animated circles */}
        <div style={{ position: "absolute", top: -40, right: -40, width: 220, height: 220, borderRadius: "50%", background: "rgba(255,255,255,0.1)", animation: "pulse 3s ease-in-out infinite" }} />
        <div style={{ position: "absolute", bottom: -20, right: 200, width: 120, height: 120, borderRadius: "50%", background: "rgba(255,255,255,0.08)", animation: "pulse 4s ease-in-out infinite reverse" }} />
        <div style={{ position: "absolute", top: "50%", left: -30, width: 150, height: 150, borderRadius: "50%", background: "rgba(255,255,255,0.06)", animation: "float 5s ease-in-out infinite" }} />
        
        <div style={{ position: "relative", zIndex: 1 }}>
          <h2 style={{ margin: "0 0 10px", fontSize: "2rem", fontWeight: 900, color: "#fff", letterSpacing: "-0.6px" }}>
            Prêt à décrocher votre prochain emploi ?
          </h2>
          <p style={{ margin: 0, color: "rgba(255,255,255,0.9)", fontSize: "1rem", fontWeight: 500 }}>
            Créez votre CV professionnel en moins de 10 minutes, entièrement gratuit.
          </p>
        </div>
        <button
          onClick={onStart}
          style={{
            flexShrink: 0,
            background: "#fff",
            color: "#8b5cf6",
            border: "none",
            borderRadius: 14,
            padding: "16px 36px",
            fontSize: "0.95rem",
            fontWeight: 800,
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            gap: 8,
            boxShadow: "0 8px 30px rgba(0,0,0,0.3)",
            position: "relative",
            zIndex: 1,
            transition: "all 0.3s"
          }}
          onMouseEnter={e => { e.currentTarget.style.transform = "scale(1.05)"; e.currentTarget.style.boxShadow = "0 12px 40px rgba(0,0,0,0.4)"; }}
          onMouseLeave={e => { e.currentTarget.style.transform = "scale(1)"; e.currentTarget.style.boxShadow = "0 8px 30px rgba(0,0,0,0.3)"; }}
        >
          Commencer maintenant
          <ChevronRight size={18} />
        </button>
      </section>

      {/* Footer */}
      <footer style={{ borderTop: "2px solid rgba(139,92,246,0.2)", padding: "32px 40px", background: "rgba(255,255,255,0.7)", backdropFilter: "blur(10px)" }}>
        <div style={{ maxWidth: 1180, margin: "0 auto", display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 12 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <div style={{ 
              width: 28, height: 28, borderRadius: 8, 
              background: "linear-gradient(135deg, #ec4899, #8b5cf6)", 
              display: "flex", alignItems: "center", justifyContent: "center",
              boxShadow: "0 4px 12px rgba(139,92,246,0.4)"
            }}>
              <FileText size={14} color="#fff" />
            </div>
            <span style={{ fontSize: "0.85rem", fontWeight: 800, background: "linear-gradient(135deg, #ec4899, #8b5cf6)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
              CV Pro Sénégal
            </span>
          </div>
          <span style={{ fontSize: "0.75rem", color: "#64748b", fontWeight: 500 }}>© 2026 · Créez votre CV professionnel gratuitement</span>
          <div style={{ display: "flex", gap: 20 }}>
            {[
              { name: "Confidentialité", color: "#ec4899" },
              { name: "CGU", color: "#8b5cf6" },
              { name: "Contact", color: "#06b6d4" }
            ].map(l => (
              <a key={l.name} href="#" style={{ fontSize: "0.75rem", color: "#64748b", textDecoration: "none", fontWeight: 600, transition: "all 0.2s" }}
                onMouseEnter={e => { e.currentTarget.style.color = l.color; }}
                onMouseLeave={e => { e.currentTarget.style.color = "#64748b"; }}
              >{l.name}</a>
            ))}
          </div>
        </div>
      </footer>

      <style>{`
        @keyframes gradientShift {
          0%, 100% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
        }
        @keyframes float {
          0%, 100% { transform: translateY(0px) translateX(0px); }
          50% { transform: translateY(-20px) translateX(10px); }
        }
        @keyframes pulse {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.8; transform: scale(1.1); }
        }
        @keyframes bounce {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-5px); }
        }
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        @keyframes slideInLeft {
          from { opacity: 0; transform: translateX(-20px); }
          to { opacity: 1; transform: translateX(0); }
        }
        @keyframes shimmer {
          from { transform: translateX(-100%); }
          to { transform: translateX(100%); }
        }
      `}</style>
    </div>
  );
}

function ActionCard({ icon: Icon, title, desc, primary, gradient, onClick }: {
  icon: React.ComponentType<{ size?: number; color?: string }>;
  title: string; desc: string; primary?: boolean; gradient?: string; onClick: () => void;
}) {
  const [hovered, setHovered] = useState(false);
  const bg = primary ? gradient || "linear-gradient(135deg, #ec4899, #8b5cf6)" : (hovered ? "#fafafa" : "#fff");

  return (
    <button
      onClick={onClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        display: "flex",
        alignItems: "center",
        gap: 14,
        padding: "16px 20px",
        borderRadius: 16,
        border: primary ? "none" : "2px solid #e2e8f0",
        background: bg,
        cursor: "pointer",
        textAlign: "left",
        transition: "all 0.3s ease",
        boxShadow: primary 
          ? "0 8px 30px rgba(139,92,246,0.4)" 
          : (hovered ? "0 8px 30px rgba(139,92,246,0.2)" : "0 2px 8px rgba(0,0,0,0.08)"),
        width: "100%",
        transform: hovered ? "translateY(-3px)" : "translateY(0)"
      }}
    >
      <div style={{ 
        width: 46, height: 46, borderRadius: 14, 
        background: primary ? "rgba(255,255,255,0.25)" : gradient || "linear-gradient(135deg, #ec4899, #8b5cf6)", 
        display: "flex", alignItems: "center", justifyContent: "center", 
        flexShrink: 0,
        boxShadow: primary ? "0 4px 12px rgba(255,255,255,0.2)" : "0 4px 12px rgba(139,92,246,0.3)"
      }}>
        <Icon size={22} color={primary ? "#fff" : "#fff"} />
      </div>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: "0.92rem", fontWeight: 800, color: primary ? "#fff" : "#0f172a", marginBottom: 3 }}>{title}</div>
        <div style={{ fontSize: "0.78rem", color: primary ? "rgba(255,255,255,0.85)" : "#64748b", fontWeight: 500 }}>{desc}</div>
      </div>
      <ChevronRight size={18} color={primary ? "rgba(255,255,255,0.7)" : "#94a3b8"} style={{ transition: "transform 0.3s", transform: hovered ? "translateX(4px)" : "translateX(0)" }} />
    </button>
  );
}

function TemplateShowcase({ name, desc, badge, badgeGradient, onClick, children }: {
  name: string; desc: string; badge: string; badgeGradient: string;
  onClick: () => void; children: React.ReactNode;
}) {
  const [hovered, setHovered] = useState(false);

  return (
    <div 
      style={{ 
        borderRadius: 24, 
        border: "2px solid rgba(139,92,246,0.2)", 
        overflow: "hidden", 
        background: "#fff", 
        boxShadow: hovered ? "0 20px 60px rgba(139,92,246,0.3)" : "0 8px 30px rgba(0,0,0,0.1)",
        transition: "all 0.4s ease",
        transform: hovered ? "translateY(-8px)" : "translateY(0)"
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      {/* Preview */}
      <div style={{ height: 340, overflow: "hidden", background: "linear-gradient(135deg, #f8fafc, #fef3c7)", position: "relative", cursor: "pointer" }} onClick={onClick}>
        {children}
        <div style={{ position: "absolute", inset: 0, background: "linear-gradient(transparent 60%, rgba(248,250,252,0.95))" }} />
        <div style={{ 
          position: "absolute", top: 14, right: 14, 
          background: badgeGradient, 
          color: "#fff", fontSize: "0.72rem", fontWeight: 800, 
          padding: "6px 14px", borderRadius: 24,
          boxShadow: "0 4px 16px rgba(0,0,0,0.2)"
        }}>
          {badge}
        </div>
      </div>
      {/* Info */}
      <div style={{ padding: "24px 28px" }}>
        <h3 style={{ margin: "0 0 8px", fontSize: "1rem", fontWeight: 800, color: "#0f172a" }}>{name}</h3>
        <p style={{ margin: "0 0 18px", fontSize: "0.8rem", color: "#64748b", lineHeight: 1.6, fontWeight: 500 }}>{desc}</p>
        <button
          onClick={onClick}
          style={{
            background: badgeGradient,
            backgroundSize: "200% 200%",
            animation: hovered ? "gradientShift 2s ease infinite" : "none",
            color: "#fff", border: "none", borderRadius: 12,
            padding: "11px 24px", fontSize: "0.82rem", fontWeight: 700, cursor: "pointer",
            display: "flex", alignItems: "center", gap: 6,
            boxShadow: "0 4px 16px rgba(139,92,246,0.3)",
            transition: "all 0.3s"
          }}
          onMouseEnter={e => { e.currentTarget.style.transform = "translateX(4px)"; }}
          onMouseLeave={e => { e.currentTarget.style.transform = "translateX(0)"; }}
        >
          Utiliser ce template
          <ArrowRight size={14} />
        </button>
      </div>
    </div>
  );
}