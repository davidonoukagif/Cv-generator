import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";

interface ScheduleEntry {
  id: string;
  time: string;
  subject: string;
  teacher: string;
  room: string;
  type: "cours" | "td" | "tp";
}

interface DaySchedule {
  day: string;
  date: string;
  entries: ScheduleEntry[];
}

const scheduleData: DaySchedule[] = [
  {
    day: "Lundi",
    date: "10 Fév",
    entries: [
      { id: "1", time: "08:00 - 10:00", subject: "Mathématiques", teacher: "M. Dupont", room: "Salle 201", type: "cours" },
      { id: "2", time: "10:15 - 12:15", subject: "Physique", teacher: "Mme Martin", room: "Lab 102", type: "tp" },
      { id: "3", time: "14:00 - 16:00", subject: "Français", teacher: "Mme Bernard", room: "Salle 105", type: "cours" },
    ]
  },
  {
    day: "Mardi",
    date: "11 Fév",
    entries: [
      { id: "4", time: "08:00 - 10:00", subject: "Anglais", teacher: "M. Smith", room: "Salle 301", type: "cours" },
      { id: "5", time: "10:15 - 12:15", subject: "Histoire", teacher: "M. Lefèvre", room: "Salle 203", type: "cours" },
      { id: "6", time: "14:00 - 16:00", subject: "Informatique", teacher: "M. Garcia", room: "Lab Info", type: "td" },
    ]
  },
  {
    day: "Mercredi",
    date: "12 Fév",
    entries: [
      { id: "7", time: "08:00 - 10:00", subject: "Mathématiques", teacher: "M. Dupont", room: "Salle 201", type: "td" },
      { id: "8", time: "10:15 - 12:15", subject: "Sport", teacher: "M. Rousseau", room: "Gymnase", type: "tp" },
    ]
  },
  {
    day: "Jeudi",
    date: "13 Fév",
    entries: [
      { id: "9", time: "08:00 - 10:00", subject: "Chimie", teacher: "Mme Petit", room: "Lab 103", type: "tp" },
      { id: "10", time: "10:15 - 12:15", subject: "Philosophie", teacher: "M. Moreau", room: "Salle 401", type: "cours" },
      { id: "11", time: "14:00 - 16:00", subject: "Anglais", teacher: "M. Smith", room: "Salle 301", type: "td" },
    ]
  },
  {
    day: "Vendredi",
    date: "14 Fév",
    entries: [
      { id: "12", time: "08:00 - 10:00", subject: "SVT", teacher: "Mme Thomas", room: "Lab Bio", type: "cours" },
      { id: "13", time: "10:15 - 12:15", subject: "Géographie", teacher: "M. Laurent", room: "Salle 204", type: "cours" },
      { id: "14", time: "14:00 - 16:00", subject: "Arts", teacher: "Mme Dubois", room: "Atelier", type: "cours" },
    ]
  },
];

export function WeeklySchedule() {
  const getTypeColor = (type: string) => {
    switch (type) {
      case "cours":
        return "bg-blue-100 text-blue-700 border-blue-200";
      case "td":
        return "bg-green-100 text-green-700 border-green-200";
      case "tp":
        return "bg-purple-100 text-purple-700 border-purple-200";
      default:
        return "bg-gray-100 text-gray-700 border-gray-200";
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Emploi du temps - Semaine du 10 Février 2026</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5">
          {scheduleData.map((day) => (
            <div
              key={day.day}
              className="border rounded-lg p-4 bg-gradient-to-br from-white to-gray-50"
            >
              <div className="mb-3 pb-2 border-b">
                <h3 className="font-semibold text-lg">{day.day}</h3>
                <p className="text-sm text-muted-foreground">{day.date}</p>
              </div>
              <div className="space-y-3">
                {day.entries.map((entry) => (
                  <div
                    key={entry.id}
                    className="p-3 rounded-lg border bg-white shadow-sm hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-start justify-between mb-2">
                      <span className="text-xs font-medium text-muted-foreground">
                        {entry.time}
                      </span>
                      <Badge
                        variant="outline"
                        className={`text-xs uppercase ${getTypeColor(entry.type)}`}
                      >
                        {entry.type}
                      </Badge>
                    </div>
                    <h4 className="font-semibold text-sm mb-1">
                      {entry.subject}
                    </h4>
                    <p className="text-xs text-muted-foreground">
                      {entry.teacher}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      📍 {entry.room}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-6 flex gap-4 justify-center flex-wrap">
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="bg-blue-100 text-blue-700 border-blue-200">
              COURS
            </Badge>
            <span className="text-sm text-muted-foreground">Cours magistral</span>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="bg-green-100 text-green-700 border-green-200">
              TD
            </Badge>
            <span className="text-sm text-muted-foreground">Travaux dirigés</span>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="bg-purple-100 text-purple-700 border-purple-200">
              TP
            </Badge>
            <span className="text-sm text-muted-foreground">Travaux pratiques</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
