import type { CVData } from "../types/cv.types";

const STORAGE_KEY = "cv_builder_data";

export const saveCVData = (data: CVData): void => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (error) {
    console.error("Error saving CV data:", error);
  }
};

export const loadCVData = (): CVData | null => {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    if (data) {
      return JSON.parse(data);
    }
  } catch (error) {
    console.error("Error loading CV data:", error);
  }
  return null;
};

export const clearCVData = (): void => {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch (error) {
    console.error("Error clearing CV data:", error);
  }
};
