export const validateEmail = (email: string): boolean => {
  const emailRegex = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i;
  return emailRegex.test(email);
};

export const validateSenegalPhone = (phone: string): boolean => {
  // Format sénégalais: +221 XX XXX XX XX ou 77/78/76/70/75 XXX XX XX
  const phoneRegex = /^(\+221|00221)?(7[0|5|6|7|8])\d{7}$/;
  const cleanPhone = phone.replace(/\s/g, "");
  return phoneRegex.test(cleanPhone);
};

export const validatePassword = (password: string): boolean => {
  return password.length >= 6;
};

export const validateRequired = (value: string): boolean => {
  return value.trim().length > 0;
};

export const getEmailError = (email: string): string | null => {
  if (!validateRequired(email)) {
    return "L'email est requis";
  }
  if (!validateEmail(email)) {
    return "Format d'email invalide";
  }
  return null;
};

export const getPhoneError = (phone: string): string | null => {
  if (!validateRequired(phone)) {
    return "Le numéro de téléphone est requis";
  }
  if (!validateSenegalPhone(phone)) {
    return "Format de téléphone sénégalais invalide (ex: 77 123 45 67 ou +221 77 123 45 67)";
  }
  return null;
};

export const getPasswordError = (password: string): string | null => {
  if (!validateRequired(password)) {
    return "Le mot de passe est requis";
  }
  if (!validatePassword(password)) {
    return "Le mot de passe doit contenir au minimum 6 caractères";
  }
  return null;
};

export const getRequiredError = (fieldName: string, value: string): string | null => {
  if (!validateRequired(value)) {
    return `${fieldName} est requis`;
  }
  return null;
};
